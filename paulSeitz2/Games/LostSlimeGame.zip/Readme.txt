Run application untitled 

controls: arrow keys or touchscreen